-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role text not null default 'student' check (role in ('admin','student')),
  created_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.materials (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  description text,
  file_url text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.announcements enable row level security;
alter table public.materials enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- Create a profile automatically whenever a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

drop policy if exists "Profiles readable by signed in users" on public.profiles;
create policy "Profiles readable by signed in users" on public.profiles
for select to authenticated using (true);

drop policy if exists "Users update own safe profile fields" on public.profiles;
-- No user-facing update policy: role cannot be changed from the client.

drop policy if exists "Announcements readable by everyone" on public.announcements;
create policy "Announcements readable by everyone" on public.announcements
for select using (true);
drop policy if exists "Admins insert announcements" on public.announcements;
create policy "Admins insert announcements" on public.announcements
for insert to authenticated with check (public.is_admin());
drop policy if exists "Admins update announcements" on public.announcements;
create policy "Admins update announcements" on public.announcements
for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Admins delete announcements" on public.announcements;
create policy "Admins delete announcements" on public.announcements
for delete to authenticated using (public.is_admin());

drop policy if exists "Materials readable by everyone" on public.materials;
create policy "Materials readable by everyone" on public.materials
for select using (true);
drop policy if exists "Admins insert materials" on public.materials;
create policy "Admins insert materials" on public.materials
for insert to authenticated with check (public.is_admin());
drop policy if exists "Admins update materials" on public.materials;
create policy "Admins update materials" on public.materials
for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Admins delete materials" on public.materials;
create policy "Admins delete materials" on public.materials
for delete to authenticated using (public.is_admin());

-- Enable live updates for shared content.
do $$
begin
  alter publication supabase_realtime add table public.announcements;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.materials;
exception when duplicate_object then null;
when undefined_object then null;
end $$;

-- IMPORTANT: After you create your own account, run this command once,
-- replacing the email with the exact email you used to sign up:
-- update public.profiles set role = 'admin' where email = 'YOUR-EMAIL@example.com';
