import OpenAI from "openai";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { text, mode } = await request.json();
    if (typeof text !== "string" || !text.trim()) {
      return NextResponse.json({ error: "أرسل نص المحاضرة أولًا." }, { status: 400 });
    }
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "الذكاء الاصطناعي غير مفعّل بعد. أضف OPENAI_API_KEY في إعدادات الاستضافة." }, { status: 503 });
    }
    const prompts: Record<string, string> = {
      explain: "اشرح النص التالي بالعربية المصرية البسيطة والمنظمة، مع الحفاظ على الدقة العلمية وشرح المصطلحات.",
      summary: "لخّص النص التالي بالعربية في عناوين ونقاط أساسية، ولا تضف معلومات غير موجودة في النص.",
      terms: "استخرج المصطلحات الإنجليزية أو العلمية من النص، واكتب لكل مصطلح معناه بالعربية وطريقة نطقه بالعربية إن أمكن. إذا لم توجد مصطلحات فاذكر ذلك.",
      quiz: "أنشئ 8 أسئلة تدريبية متنوعة من النص بالعربية (اختيار من متعدد وصح وخطأ)، وضع الإجابات في قسم منفصل في النهاية."
    };
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "أنت مساعد تعليمي دقيق. اعتمد على النص المرسل، ونبّه إذا كانت المعلومة غير كافية. استخدم تنسيقًا واضحًا مناسبًا للطلاب." },
        { role: "user", content: `${prompts[mode] || prompts.explain}\n\nالنص:\n${text.slice(0, 30000)}` }
      ],
      temperature: 0.4
    });
    return NextResponse.json({ result: completion.choices[0]?.message?.content || "لم أستطع إنشاء نتيجة." });
  } catch {
    return NextResponse.json({ error: "حدث خطأ أثناء معالجة المحاضرة. حاول مرة أخرى." }, { status: 500 });
  }
}
