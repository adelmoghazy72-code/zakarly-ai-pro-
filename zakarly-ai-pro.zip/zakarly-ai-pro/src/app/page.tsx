"use client";

import { useEffect, useState } from "react";
import { BookOpen, BrainCircuit, FileText, GraduationCap, LogIn, LogOut, Menu, Plus, Sparkles, Upload, Users, X, ShieldCheck, Bell, ChevronLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

type Profile = { id: string; email: string; full_name: string | null; role: "admin" | "student" };
type Announcement = { id: string; title: string; body: string; created_at: string };
type Material = { id: string; title: string; subject: string; description: string | null; file_url: string | null; created_at: string };

const supabase = createClient();

export default function Home() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [activeTool, setActiveTool] = useState<"explain" | "summary" | "terms" | "quiz">("explain");
  const [lecture, setLecture] = useState("");
  const [aiResult, setAiResult] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newBody, setNewBody] = useState("");
  const [newSubject, setNewSubject] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);

  async function loadData(userId?: string) {
    const { data: auth } = await supabase.auth.getUser();
    const user = auth.user;
    if (user) {
      const { data: p } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      setProfile(p as Profile | null);
    } else {
      setProfile(null);
    }
    const { data: a } = await supabase.from("announcements").select("*").order("created_at", { ascending: false }).limit(8);
    setAnnouncements((a || []) as Announcement[]);
    const { data: m } = await supabase.from("materials").select("*").order("created_at", { ascending: false }).limit(12);
    setMaterials((m || []) as Material[]);
  }

  useEffect(() => {
    loadData();
    const { data: authListener } = supabase.auth.onAuthStateChange(() => { loadData(); });
    const channel = supabase.channel("zakarly-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "announcements" }, () => loadData())
      .on("postgres_changes", { event: "*", schema: "public", table: "materials" }, () => loadData())
      .subscribe();
    return () => { authListener.subscription.unsubscribe(); supabase.removeChannel(channel); };
  }, []);

  async function signInOrUp(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      if (authMode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: fullName } }
        });
        if (error) throw error;
        setMessage("تم إنشاء الحساب. لو تأكيد البريد مفعّل، افتح بريدك لتأكيد الحساب ثم سجّل الدخول.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setMessage("تم تسجيل الدخول بنجاح.");
        await loadData();
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "حصل خطأ. حاول مرة أخرى.");
    } finally { setBusy(false); }
  }

  async function signOut() {
    await supabase.auth.signOut(); setProfile(null); setMessage("تم تسجيل الخروج.");
  }

  async function runAI() {
    if (!lecture.trim()) { setMessage("اكتب نص المحاضرة أولًا."); return; }
    setAiBusy(true); setAiResult(""); setMessage("");
    try {
      const res = await fetch("/api/study", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: lecture, mode: activeTool })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "تعذر تنفيذ الطلب.");
      setAiResult(data.result);
    } catch (err) {
      setAiResult(err instanceof Error ? err.message : "حصل خطأ.");
    } finally { setAiBusy(false); }
  }

  async function addAnnouncement(e: React.FormEvent) {
    e.preventDefault();
    if (!profile || profile.role !== "admin") return;
    const { error } = await supabase.from("announcements").insert({ title: newTitle, body: newBody, created_by: profile.id });
    if (error) setMessage(error.message);
    else { setNewTitle(""); setNewBody(""); setMessage("تم نشر الإعلان وسيظهر للمستخدمين."); await loadData(); }
  }

  async function addMaterial(e: React.FormEvent) {
    e.preventDefault();
    if (!profile || profile.role !== "admin") return;
    const { error } = await supabase.from("materials").insert({
      title: newTitle, subject: newSubject, description: newDescription, created_by: profile.id
    });
    if (error) setMessage(error.message);
    else { setNewTitle(""); setNewSubject(""); setNewDescription(""); setMessage("تمت إضافة المادة للموقع."); await loadData(); }
  }

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-icon"><BookOpen size={25}/></span><span>ذاكرلي <b>AI</b><small>رفيق مذاكرتك الذكي</small></span></a>
        <nav className={mobileMenu ? "nav open" : "nav"}>
          <a href="#tools" onClick={() => setMobileMenu(false)}>أدوات المذاكرة</a>
          <a href="#library" onClick={() => setMobileMenu(false)}>مكتبة المواد</a>
          <a href="#updates" onClick={() => setMobileMenu(false)}>آخر التحديثات</a>
        </nav>
        <div className="account">
          {profile ? <><span className="user-chip">{profile.role === "admin" ? <ShieldCheck size={16}/> : <GraduationCap size={16}/>} {profile.full_name || profile.email}</span>{profile.role === "admin" && <button className="icon-button" title="لوحة المالك" onClick={() => setShowAdmin(!showAdmin)}><Menu size={18}/></button>}<button className="outline-btn" onClick={signOut}><LogOut size={16}/> خروج</button></> :
          <a className="outline-btn" href="#account"><LogIn size={16}/> دخول</a>}
        </div>
        <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="القائمة">{mobileMenu ? <X/> : <Menu/>}</button>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <span className="pill"><Sparkles size={14}/> منصتك التعليمية الذكية</span>
          <h1>افهم محاضرتك.<br/><em>واتقن مذاكرتك.</em></h1>
          <p>حوّل المحاضرات المعقدة إلى شرح بسيط وملخصات وأسئلة تدريبية، في مكان واحد.</p>
          <div className="hero-actions"><a className="primary-btn" href="#tools">ابدأ المذاكرة <ChevronLeft size={18}/></a><a className="secondary-btn" href="#library">استكشف المكتبة</a></div>
          <div className="trust-row"><span><span className="dot"/> مساحة مذاكرة منظمة</span><span><span className="dot"/> تحديثات مباشرة</span></div>
        </div>
        <div className="hero-visual"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="book-emoji">📚</div><div className="float-card float-a"><BrainCircuit size={19}/><span>فهم أعمق</span></div><div className="float-card float-b"><Sparkles size={19}/><span>مذاكرة أذكى</span></div><div className="leaf">✦</div></div>
      </section>

      <section className="feature-grid">
        <article className="feature"><div className="feature-icon green"><BrainCircuit/></div><h3>شرح ذكي</h3><p>حوّل النصوص إلى شرح مبسط ومنظم.</p></article>
        <article className="feature"><div className="feature-icon gold"><FileText/></div><h3>تلخيص المحاضرات</h3><p>ركّز على الأفكار الرئيسية والنقاط المهمة.</p></article>
        <article className="feature"><div className="feature-icon blue"><GraduationCap/></div><h3>اختبر نفسك</h3><p>تدرّب بأسئلة تساعدك تراجع فهمك.</p></article>
        <article className="feature"><div className="feature-icon lilac"><Users/></div><h3>مكتبة مشتركة</h3><p>المواد التي يضيفها المالك تظهر للجميع.</p></article>
      </section>

      {message && <div className="notice" role="status">{message}<button onClick={() => setMessage("")}><X size={15}/></button></div>}

      {!profile && <section id="account" className="auth-section">
        <div><span className="eyebrow">حسابك في ذاكرلي</span><h2>{authMode === "login" ? "أهلًا بعودتك 👋" : "انضم إلى ذاكرلي"}</h2><p>سجّل الدخول لمتابعة تجربة المذاكرة والوصول إلى المكتبة المشتركة.</p></div>
        <form className="auth-form" onSubmit={signInOrUp}>
          {authMode === "signup" && <label>الاسم الظاهر<input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="اسمك" required/></label>}
          <label>البريد الإلكتروني<input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required/></label>
          <label>كلمة المرور<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="6 أحرف على الأقل" minLength={6} required/></label>
          <button className="primary-btn full" disabled={busy}>{busy ? "لحظة..." : authMode === "login" ? "تسجيل الدخول" : "إنشاء حساب"} <ChevronLeft size={17}/></button>
          <button type="button" className="text-button" onClick={() => setAuthMode(authMode === "login" ? "signup" : "login")}>{authMode === "login" ? "ليس لديك حساب؟ أنشئ حسابًا" : "لديك حساب بالفعل؟ سجّل الدخول"}</button>
        </form>
      </section>}

      {showAdmin && profile?.role === "admin" && <section className="admin-panel">
        <div className="section-title"><div><span className="eyebrow">صلاحيات المالك</span><h2>لوحة التحكم</h2><p>أي إعلان أو مادة تضيفها هنا تظهر لجميع زوار الموقع المتصلين بقاعدة البيانات نفسها.</p></div><button className="icon-button" onClick={() => setShowAdmin(false)}><X/></button></div>
        <div className="admin-grid">
          <form className="admin-form" onSubmit={addAnnouncement}><h3><Bell size={18}/> نشر إعلان عام</h3><label>عنوان الإعلان<input value={newTitle} onChange={e=>setNewTitle(e.target.value)} required/></label><label>محتوى الإعلان<textarea value={newBody} onChange={e=>setNewBody(e.target.value)} required/></label><button className="primary-btn full"><Plus size={17}/> نشر للجميع</button></form>
          <form className="admin-form" onSubmit={addMaterial}><h3><BookOpen size={18}/> إضافة مادة للمكتبة</h3><label>اسم المادة<input value={newSubject} onChange={e=>setNewSubject(e.target.value)} required/></label><label>عنوان المحتوى<input value={newTitle} onChange={e=>setNewTitle(e.target.value)} required/></label><label>وصف مختصر<textarea value={newDescription} onChange={e=>setNewDescription(e.target.value)}/></label><button className="primary-btn full"><Plus size={17}/> إضافة للمكتبة</button></form>
        </div>
      </section>}

      <section id="tools" className="study-section">
        <div className="section-title"><div><span className="eyebrow">مساعدك الدراسي</span><h2>خلّي المحاضرة أوضح</h2><p>الصق نص المحاضرة، واختار الأداة المناسبة ليك.</p></div><span className="section-mark"><Sparkles/></span></div>
        <div className="study-layout">
          <div className="study-input">
            <label className="field-title">محتوى المحاضرة</label>
            <textarea className="lecture-box" value={lecture} onChange={e=>setLecture(e.target.value)} placeholder="الصق هنا نص المحاضرة أو جزءًا منها..."/>
            <div className="tool-options">
              <button className={activeTool==="explain"?"tool-choice selected":"tool-choice"} onClick={()=>setActiveTool("explain")}><BrainCircuit/> <span>اشرحلي</span></button>
              <button className={activeTool==="summary"?"tool-choice selected":"tool-choice"} onClick={()=>setActiveTool("summary")}><FileText/> <span>لخّصلي</span></button>
              <button className={activeTool==="terms"?"tool-choice selected":"tool-choice"} onClick={()=>setActiveTool("terms")}><BookOpen/> <span>المصطلحات</span></button>
              <button className={activeTool==="quiz"?"tool-choice selected":"tool-choice"} onClick={()=>setActiveTool("quiz")}><GraduationCap/> <span>أسئلة تدريب</span></button>
            </div>
            <button className="primary-btn full" onClick={runAI} disabled={aiBusy}>{aiBusy ? "جاري تجهيز النتيجة..." : "ابدأ المذاكرة"} <Sparkles size={17}/></button>
            {aiResult && <div className="ai-result"><h3>النتيجة</h3><div>{aiResult}</div></div>}
            <p className="fine-print">تحتاج أدوات الذكاء الاصطناعي إلى ضبط مفتاح API في إعدادات الاستضافة.</p>
          </div>
          <aside className="study-aside"><div className="aside-illustration">🌿</div><h3>خطوة صغيرة كل يوم</h3><p>ذاكر جزءًا، افهمه، ثم اختبر نفسك. التقدم المنتظم يصنع فرقًا.</p><div className="mini-stat"><span>01</span><div><b>اقرأ</b><small>حدد الفكرة الرئيسية</small></div></div><div className="mini-stat"><span>02</span><div><b>افهم</b><small>استخدم الشرح والتلخيص</small></div></div><div className="mini-stat"><span>03</span><div><b>راجع</b><small>اختبر نفسك بالأسئلة</small></div></div></aside>
        </div>
      </section>

      <section id="library" className="content-section">
        <div className="section-title"><div><span className="eyebrow">المحتوى المشترك</span><h2>مكتبة المواد</h2><p>المحتوى المنشور محفوظ على الإنترنت ويظهر لكل المستخدمين.</p></div><BookOpen className="section-mark"/></div>
        {materials.length ? <div className="materials-grid">{materials.map(m=><article className="material-card" key={m.id}><div className="material-top"><div className="feature-icon green"><BookOpen/></div><span className="material-tag">{m.subject}</span></div><h3>{m.title}</h3><p>{m.description || "محتوى دراسي أضيف إلى المكتبة."}</p><small>{new Date(m.created_at).toLocaleDateString("ar-EG")}</small></article>)}</div> : <div className="empty-state"><div><BookOpen size={28}/></div><h3>مكتبتك لسه بتبدأ</h3><p>لما المالك يضيف مواد من لوحة التحكم، هتظهر هنا لكل المستخدمين.</p></div>}
      </section>

      <section id="updates" className="content-section updates-section">
        <div className="section-title"><div><span className="eyebrow">الجديد أولًا بأول</span><h2>آخر التحديثات</h2><p>إعلانات الموقع وتحديثاته المهمة.</p></div><Bell className="section-mark"/></div>
        {announcements.length ? <div className="updates-list">{announcements.map(a=><article className="update-card" key={a.id}><div className="update-icon"><Bell size={19}/></div><div><h3>{a.title}</h3><p>{a.body}</p><small>{new Date(a.created_at).toLocaleDateString("ar-EG")}</small></div></article>)}</div> : <div className="empty-state compact"><p>لا توجد إعلانات حاليًا. أي إعلان جديد من المالك سيظهر هنا مباشرة.</p></div>}
      </section>

      <footer className="footer"><a className="brand footer-brand" href="#"><span className="brand-icon"><BookOpen size={20}/></span><span>ذاكرلي <b>AI</b></span></a><p>مساحتك لفهم أفضل ومذاكرة أذكى.</p><small>© {new Date().getFullYear()} ذاكرلي AI · جميع الحقوق محفوظة لمالك الموقع</small></footer>
    </main>
  );
}
