import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ذاكرلي AI | رفيق مذاكرتك الذكي",
  description: "منصة تعليمية ذكية لشرح المحاضرات وتلخيصها وإنشاء اختبارات تدريبية.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
